#pragma once

#define sleep(x) Sleep(x * 1000)
